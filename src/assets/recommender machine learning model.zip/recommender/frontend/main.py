from flask import Flask, jsonify
import recommend as rec
import os


app = Flask(__name__)

@app.route("/")
def root():
    result = {
        'status' : 200, 'message' : 'Etterra recommendation system.'
    }
    return jsonify(result)

@app.route("/recommendDish/<dishName>/<num>",)
def recommend_dish(dishName, num):
    return jsonify(rec.recommend_dishes(dishName, num))

@app.route("/recommendUser/<userId>/<num>",)
def recommend_user(userId, num = None):
    return jsonify(rec.recommend_users(userId, num))


if __name__ == "__main__":
    app.run(debug=True, port = 8080, host='0.0.0.0')