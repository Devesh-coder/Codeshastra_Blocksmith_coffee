import train as tr
import pandas as pd
import os.path

def recommend_users(userId, number):
    similar_users = pd.read_pickle('similar_users.pkl')
    df = pd.read_csv('dataset.csv')

    index = df[df['user_id'] == int(userId)].index[0]
    top_similar_users = sorted(list(enumerate(similar_users[index])), reverse=True, key = lambda x:x[1])[1:int(number)+1]
    result = []
    
    for i in top_similar_users:
        result.append(df.iloc[i[0]]['user_id'])
    return result



def recommend_dishes(dishName, number):

    dish_names = ['user_id','filtercoffee','Irishfrappe','kaapi','espresso','minisamosa','bananachips','crinkle','papparoti','bread','berliner','age']
    similar_dishes = pd.read_pickle('similar_dishes.pkl')


    index = dish_names.index(dishName)
    final_result = sorted(list(enumerate(similar_dishes[index])), reverse=True, key=lambda x:x[1])[1:int(number)+1]
    output = []
    for i in final_result:
        output.append(dish_names[i[0]])
    print(output)
    return output
